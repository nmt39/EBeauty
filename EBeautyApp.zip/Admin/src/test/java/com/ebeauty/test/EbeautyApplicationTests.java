package com.ebeauty.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbeautyApplicationTests {

	@Test
	void contextLoads() {
	}

}
